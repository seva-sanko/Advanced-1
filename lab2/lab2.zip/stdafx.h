﻿#pragma once
#include <cmath> 
#include <iostream>	 // Эта - часть библиотеки STL (Standard Template Library)
#include <limits>	 // Полезные константы
#include <cstring>
#include <intrin.h> // Для __nop

using namespace std;	 // Обеспечивает видимость имен из STL

#define	  stop __nop();
